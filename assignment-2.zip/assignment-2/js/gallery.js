// gallery.js

// Function to handle the click event on thumbnail images
function showImage(event) {
    const featuredImage = document.getElementById('featuredImage');
    const imageCaption = document.getElementById('imageCaption');
    
    // Change the source and caption of the featured image based on the clicked thumbnail
    featuredImage.src = event.target.src.replace('-small', '-large');
    imageCaption.textContent = event.target.alt;
  }
  
  // Attach the click event to each thumbnail image
  const thumbnails = document.querySelectorAll('#thumbnailList img');
  thumbnails.forEach(thumbnail => {
    thumbnail.addEventListener('click', showImage);
  });
  